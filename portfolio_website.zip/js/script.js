// Typing Effect
const typingText = document.getElementById('typingText');
const text = "Selamat datang di portfolio saya!";
let index = 0;
function typeWriter() {
    if (index < text.length) {
        typingText.innerHTML = text.substring(0, index + 1);
        index++;
        setTimeout(typeWriter, 50);
    } else {
        typingText.classList.remove('typing-effect');
    }
}

// Music Player
const musicPlayer = document.getElementById('musicPlayer');
const backgroundMusic = document.getElementById('backgroundMusic');
let isPlaying = false;

musicPlayer.addEventListener('click', function() {
    if (isPlaying) {
        backgroundMusic.pause();
        musicPlayer.innerHTML = '<i class="fas fa-music"></i>';
    } else {
        backgroundMusic.play();
        musicPlayer.innerHTML = '<i class="fas fa-pause"></i>';
    }
    isPlaying = !isPlaying;
});

// Navigation
function navigateTo(pageId) {
    document.querySelectorAll('.page').forEach(page => {
        page.classList.remove('active');
    });
    document.getElementById(pageId).classList.add('active');
    window.scrollTo(0, 0);
    if (pageId === 'home') {
        index = 0;
        typingText.classList.add('typing-effect');
        typeWriter();
    }
}
window.addEventListener('load', function() { typeWriter(); });
